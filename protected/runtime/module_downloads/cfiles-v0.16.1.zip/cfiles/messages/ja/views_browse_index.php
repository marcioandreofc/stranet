<?php
return array (
  'Could not save file %title%. ' => 'ファイル %title% を保存できませんでした。',
);
