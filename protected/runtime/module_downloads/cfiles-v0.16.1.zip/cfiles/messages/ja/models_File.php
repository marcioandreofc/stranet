<?php
return array (
  'Folder ID' => 'フォルダー ID',
);
