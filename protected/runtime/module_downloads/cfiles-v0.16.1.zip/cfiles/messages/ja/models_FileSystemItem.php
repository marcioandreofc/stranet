<?php
return array (
  'Downloads' => 'ダウンロード',
  'Is Public' => '公開中',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => '注：フォルダーの可視性の変更は含まれている全てのファイルとフォルダーに継承されます。',
);
