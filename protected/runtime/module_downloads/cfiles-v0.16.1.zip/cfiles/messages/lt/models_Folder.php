<?php
return array (
  'Description' => 'Aprašymas',
  'Parent Folder ID' => '',
  'Title' => 'Pavadinimas',
);
