<?php
return array (
  'Description' => 'Açıklama',
  'Parent Folder ID' => '',
  'Title' => 'Başlık',
);
