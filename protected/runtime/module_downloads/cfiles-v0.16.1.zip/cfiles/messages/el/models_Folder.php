<?php
return array (
  'Description' => 'Περιγραφή',
  'Parent Folder ID' => 'Αναγνωριστικό (ID) γονικού φακέλου',
  'Title' => 'Τίτλος',
);
