<?php
return array (
  'Downloads' => 'Λήψεις',
  'Is Public' => 'Είναι δημόσιο',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Σημείωση: Οι αλλαγές στην προβολή των φακέλων θα κληρονομηθούν από όλα τα αρχεία και τους φακέλους που περιέχονται.',
);
