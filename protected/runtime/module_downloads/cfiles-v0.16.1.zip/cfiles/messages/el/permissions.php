<?php
return array (
  'Add files' => 'Προσθήκη αρχείων',
  'Allows the user to modify or delete any files.' => 'Επιτρέπει στο χρήστη να τροποποιεί ή να διαγράφει οποιαδήποτε αρχεία.',
  'Allows the user to upload new files and create folders' => 'Επιτρέπει στο χρήστη να ανεβάζει νέα αρχεία και να δημιουργεί φακέλους',
  'Manage files' => 'Διαχείριση αρχείων',
);
