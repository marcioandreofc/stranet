<?php
return array (
  'Could not save file %title%. ' => 'Δεν ήταν δυνατή η αποθήκευση του αρχείου %title%.',
);
