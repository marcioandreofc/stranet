<?php

return [
    'Add files' => '',
    'Allows the user to modify or delete any files.' => '',
    'Allows the user to upload new files and create folders' => '',
    'Manage files' => '',
];
