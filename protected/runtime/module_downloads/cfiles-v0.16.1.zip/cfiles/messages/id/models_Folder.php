<?php
return array (
  'Description' => 'Deskripsi',
  'Parent Folder ID' => '',
  'Title' => 'Judul',
);
