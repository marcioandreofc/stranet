<?php
return array (
  'Description' => 'Beschrijving',
  'Parent Folder ID' => 'Bovenliggende map ID',
  'Title' => 'Titel',
);
