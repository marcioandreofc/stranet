<?php
return array (
  'Are you really sure to delete this version?' => 'Tens a certeza de que pretendes eliminar esta versão?',
  'The version "{versionDate}" could not be deleted!' => 'Não foi possível eliminar a versão "{versionDate}"!',
  'The version "{versionDate}" has been deleted.' => 'A versão "{versionDate}" foi eliminada.',
);
