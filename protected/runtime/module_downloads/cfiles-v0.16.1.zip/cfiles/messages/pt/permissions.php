<?php
return array (
  'Add files' => 'Adicionar ficheiros',
  'Allows the user to modify or delete any files.' => 'Permite à pessoa modificar ou eliminar ficheiros',
  'Allows the user to upload new files and create folders' => 'Permite à pessoa carregar novos ficheiros e criar pastas',
  'Manage files' => 'Gerir ficheiros',
);
