<?php
return array (
  'Add files' => 'Adicionar arquivos',
  'Allows the user to modify or delete any files.' => 'Permitir que o usuário modifique ou apague qualquer arquivo.',
  'Allows the user to upload new files and create folders' => 'Permitir que o usuário transfira novos arquivos e crie pastas',
  'Manage files' => 'Administrar arquivos',
);
