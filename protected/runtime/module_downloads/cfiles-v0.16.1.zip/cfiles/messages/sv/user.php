<?php
return array (
  'Are you really sure to delete this version?' => 'Är du verkligen säker på att ta bort den här versionen?',
  'The version "{versionDate}" could not be deleted!' => 'Versionen "{versionDate}" kunde inte raderas!',
  'The version "{versionDate}" has been deleted.' => 'Versionen "{versionDate}" har tagits bort.',
);
