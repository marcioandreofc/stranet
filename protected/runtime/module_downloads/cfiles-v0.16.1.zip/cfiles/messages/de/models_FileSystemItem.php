<?php
return array (
  'Downloads' => 'Downloads',
  'Is Public' => 'Ist öffentlich',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Hinweis: Änderungen an der Sichtbarkeit des Ordners werden auch auf alle darin enthaltenen Dateien und Ordner übertragen.',
);
