<?php

return [
    'Folder ID' => 'Ordner ID',
];
