<?php
return array (
  'Add files' => 'Dateien hinzufügen',
  'Allows the user to modify or delete any files.' => 'Erlaubt dem Benutzer, beliebige Dateien zu ändern oder zu löschen.',
  'Allows the user to upload new files and create folders' => 'Erlaubt dem Benutzer, neue Dateien hochzuladen und Ordner zu erstellen',
  'Manage files' => 'Dateien verwalten',
);
