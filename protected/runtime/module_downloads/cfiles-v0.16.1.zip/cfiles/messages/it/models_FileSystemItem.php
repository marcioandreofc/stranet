<?php
return array (
  'Downloads' => 'Download',
  'Is Public' => 'è pubblico',
  'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => 'Nota: Il cambiamento della visibilità della cartella saranno ereditati da tutti i file e cartelle.',
);
