<?php
return array (
  'Add files' => 'Ajouter des fichiers',
  'Allows the user to modify or delete any files.' => 'Autoriser l\'utilisateur à modifier ou supprimer n\'importe quel fichier.',
  'Allows the user to upload new files and create folders' => 'Autoriser l\'utilisateur à ajouter de nouveaux fichiers et à créer des dossiers',
  'Manage files' => 'Gérer les fichiers',
);
