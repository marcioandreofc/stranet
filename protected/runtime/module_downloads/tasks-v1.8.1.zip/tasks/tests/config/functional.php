<?php
/**
 * Here you can overwrite the default config for the functional suite. The default config resides in @humhubTests/codeception/config/config.php
 */
return [];
