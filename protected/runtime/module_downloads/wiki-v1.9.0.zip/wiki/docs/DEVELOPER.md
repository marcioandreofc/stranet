# Developer 

## Build

In order to build script and style sources run:

```
npm install
```

and

```
grunt build
```

