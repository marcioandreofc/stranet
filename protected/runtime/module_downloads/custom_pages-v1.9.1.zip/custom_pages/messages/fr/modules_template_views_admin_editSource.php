<?php
return array (
  'Add Element' => 'Ajouter un élément',
  'Edit All' => 'Tout modifier',
  'Edit template \'{templateName}\'' => 'Modifier le modèle \'{templateName}\'',
  'Here you can edit the source of your template by defining the template layout and adding content elements. Each element can be assigned with a default content and additional definitions.' => 'Vous pouvez modifier ici le code source de votre modèle en définissant la structure du modèle et en ajoutant des éléments de contenu. Chaque élément peut être associé à un contenu par défaut et à des définitions supplémentaires.',
  'You haven\'t saved your last changes yet. Do you want to leave without saving?' => 'Vous n\'avez pas enregistré vos modifications. Voulez-vous quitter sans enregistrer ?',
);
