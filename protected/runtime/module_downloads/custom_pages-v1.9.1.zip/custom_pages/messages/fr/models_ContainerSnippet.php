<?php
return array (
  'Snippet' => 'Extrait',
  'snippet' => 'extrait',
);
