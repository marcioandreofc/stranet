<?php
return array (
  'Use default content' => 'Utiliser le contenu blanc',
);
