<?php
return array (
  'Here you can manage your snipped layouts. Snippet layouts are templates, which can be included into sidebars.' => 'Vous pouvez gérer ici vos dispositions d\'extraits. Les dispositions d\'extrait sont des modèles, qui peuvent être affichés dans les barres latérales.',
);
