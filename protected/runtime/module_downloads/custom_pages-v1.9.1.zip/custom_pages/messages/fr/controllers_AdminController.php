<?php
return array (
  '<strong>Add</strong> {templateName} item' => '<strong>Ajouter</strong> un élément {templateName}',
  '<strong>Edit</strong> item' => '<strong>Modifier</strong> l\'élément',
);
