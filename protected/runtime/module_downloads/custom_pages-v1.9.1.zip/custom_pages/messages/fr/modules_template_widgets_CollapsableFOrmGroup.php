<?php
return array (
  'Show less' => 'Afficher moins',
  'Show more' => 'Afficher plus',
);
