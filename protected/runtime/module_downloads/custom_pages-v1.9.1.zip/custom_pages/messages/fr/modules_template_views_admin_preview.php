<?php
return array (
  'Display Empty Content' => 'Afficher le contenu vide',
  'Update' => 'Mettre à jour',
);
