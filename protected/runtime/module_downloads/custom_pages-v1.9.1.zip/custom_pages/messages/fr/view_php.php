<?php
return array (
  'View not found' => 'Vue non trouvée',
);
