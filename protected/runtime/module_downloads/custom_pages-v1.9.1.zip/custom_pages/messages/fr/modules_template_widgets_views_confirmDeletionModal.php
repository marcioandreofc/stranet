<?php
return array (
  'Are you sure you want to delete this container item?' => 'Êtes-vous sur de vouloir supprimer cet élément ?',
  'Do you really want to delete this content?' => 'Êtes-vous sûr de vouloir supprimer ce contenu ?',
  'Do you really want to delete this element? <br />The deletion will affect all pages using this template.' => 'Êtes-vous sûr de vouloir supprimer cet élément ? <br />La suppression se répercutera sur toute les pages utilisant ce modèle.',
);
