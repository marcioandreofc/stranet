<?php
return array (
  'Admin only' => 'Administrateurs uniquement',
  'All Members' => 'Tous les utilisateurs',
  'Members & Guests' => 'Utilisateurs et invités (public)',
  'Members only' => 'Utilisateurs uniquement',
  'Public' => 'Public',
  'Space Members only' => 'Membres de l\'espace uniquement',
);
