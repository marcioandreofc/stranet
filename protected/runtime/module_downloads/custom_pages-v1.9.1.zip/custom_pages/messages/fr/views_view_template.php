<?php
return array (
  'Edit Template' => 'Modifier le modèle',
  'Edit elements' => 'Modifier les éléments',
  'Edit template' => 'Modifier le modèle',
  'Page configuration' => 'Configuration de la page',
  'Turn edit off' => 'Désactiver les modifications',
);
