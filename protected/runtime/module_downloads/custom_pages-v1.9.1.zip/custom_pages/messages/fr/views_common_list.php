<?php
return array (
  'This page lists all available custom content entries.' => 'Cette page présente toutes les entrées disponibles de documents personnalisés.',
);
