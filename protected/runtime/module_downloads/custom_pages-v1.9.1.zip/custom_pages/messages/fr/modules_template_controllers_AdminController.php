<?php
return array (
  '<strong>Add</strong> new {type} element' => '<strong>Ajouter</strong> nouvel élément {type}',
  '<strong>Edit</strong> element {name}' => '<strong>Modifier</strong> l\'élément {name}',
  '<strong>Edit</strong> elements of {templateName}' => '<strong>Modifier</strong> les éléments de {templateName}',
  '<strong>Edit</strong> {templateName}' => '<strong>Modifier</strong> {templateName}',
  'Template not found!' => 'Modèle non trouvé !',
  'The template could not be deleted, please get sure that this template is not in use.' => 'Ce modèle n\'a pas pu être supprimé, vérifiez que celui-ci n\'est pas en cours d\'utilisation.',
);
