<?php
return array (
  'Attach Files' => 'Transférer des fichiers',
);
