<?php
return array (
  'Edit Page' => 'Modifier Page',
);
