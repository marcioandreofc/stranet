<?php
return array (
  'none' => 'aucune',
);
