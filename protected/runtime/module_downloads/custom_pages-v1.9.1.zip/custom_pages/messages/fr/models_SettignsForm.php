<?php
return array (
  'Activate PHP based Pages and Snippets' => 'Activer les pages et les fragments de page basés sur du PHP',
  'If disabled, existing php pages will still be online, but can\'t be created.' => 'Si désactivé, les pages PHP existantes seront toujours en ligne, mais il ne sera pas possible d\'en créer de nouvelles.',
  'PHP view path for custom space pages' => 'Chemin de la vue PHP pour les pages d\'espace personnalisées',
  'PHP view path for custom space snippets' => 'Chemin de la vue PHP pour les fragments de page d\'espace personnalisés',
  'PHP view path for global custom pages' => 'Chemin de la vue PHP pour les pages générales personnalisées',
  'PHP view path for global custom snippets' => 'Chemin de la vue PHP pour les fragments de page générale personnalisés',
  'The given view file path does not exist.' => 'Le chemin donné du fichier de vue n\'existe pas.',
);
