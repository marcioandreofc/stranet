<?php
return array (
  'Here you can manage your template layouts. Layouts are the root of your template pages and can not be combined with other templates.' => 'Vous pouvez gérer ici les dispositions de votre modèle. Les dispositions sont la base des pages de votre modèle et ne peuvent être combinées avec d\'autres modèles.',
);
