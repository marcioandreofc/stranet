<?php
return array (
  'Add new {pageType}' => 'Ajouter {pageType}',
  'Create new template' => 'Créer un nouveau modèle',
  'Edit template' => 'Modifier le modèle',
  'Settings' => 'Paramètres',
);
