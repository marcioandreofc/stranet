<?php
return array (
  'Create new {type}' => 'Créer un nouveau {type}',
  'Edit template \'{templateName}\'' => 'Modifier le modèle \'{templateName}\'',
  'Save' => 'Enregistrer',
);
