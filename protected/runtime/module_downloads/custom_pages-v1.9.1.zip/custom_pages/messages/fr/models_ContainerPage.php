<?php

return [
    'Only visible for space admins' => 'Visible uniquement par les administrateurs',
    'Open in new window' => 'Ouvrir dans une nouvelle fenêtre',
];
