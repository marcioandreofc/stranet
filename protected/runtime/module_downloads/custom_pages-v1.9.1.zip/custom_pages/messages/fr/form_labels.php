<?php
return array (
  'Url' => 'URL',
  'View' => 'Afficher',
);
