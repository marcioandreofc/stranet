<?php
return array (
  'Content' => 'Contenu',
  'ID' => 'ID',
  'Icon' => 'Icône',
  'Invalid template selection!' => 'Sélection du modèle invalide.',
  'Invalid view file selection!' => 'Sélection du fichier View invalide.',
  'Sort Order' => 'Ordre de tri',
  'Style Class' => 'Classe de style',
  'Target Url' => 'URL cible',
  'Template Layout' => 'Disposition du modèle',
  'Title' => 'Titre',
  'Type' => 'Type',
);
