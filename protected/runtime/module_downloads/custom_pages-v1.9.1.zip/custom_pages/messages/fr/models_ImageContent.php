<?php
return array (
  'Empty Image' => 'Pas d\'image',
);
