<?php
return array (
  'Empty' => 'Vide',
  'Inline' => 'En ligne',
  'Multiple' => 'Multiple',
  'This template does not contain any elements yet.' => 'Ce modèle ne contient encore aucun élément.',
);
