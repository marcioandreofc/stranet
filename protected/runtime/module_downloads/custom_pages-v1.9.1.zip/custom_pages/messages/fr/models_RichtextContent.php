<?php
return array (
  'Empty HumHub Richtext' => 'Texte riche Humhub vide',
  'Empty Richtext' => 'Texte riche vide',
  'Empty Text' => 'Texte vide',
);
