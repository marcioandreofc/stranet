<?php
return array (
  'Empty <br />Container' => 'Conteneur vide<br />',
);
