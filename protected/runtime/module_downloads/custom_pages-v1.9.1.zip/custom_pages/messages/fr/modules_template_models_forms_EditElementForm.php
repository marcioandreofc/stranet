<?php
return array (
  'Use empty content' => 'Utiliser un contenu vide',
);
