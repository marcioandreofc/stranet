<?php
return array (
  'Content' => 'Contenu',
  'Sidebar' => 'Barre latérale',
  'snippet' => 'extrait',
);
