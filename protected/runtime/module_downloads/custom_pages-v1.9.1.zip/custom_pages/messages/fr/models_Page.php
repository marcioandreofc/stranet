<?php
return array (
  'Abstract' => 'Résumé',
  'Navigation' => 'Navigation',
  'Only visible for admins' => 'Visible uniquement par les administrateurs',
  'Open in new window' => 'Ouvrir dans une nouvelle fenêtre',
  'Page' => 'Page',
  'Url shortcut' => 'Raccourci',
  'View' => 'Afficher',
  'page' => 'page',
);
