<?php
return array (
  'Label' => 'Libellé',
  'Placeholder name' => 'Nom de l\'espace réservé',
  'The element name must contain at least two characters without spaces or special signs except \'_\'' => 'Le nom de l\'élément doit contenir au moins deux caractères sans espace ou caractère spécial à l\'exception du caractère "_"',
  'The given element name is already in use for this template.' => 'Le nom donné pour l\'élément est déjà utilisé dans ce modèle.',
);
