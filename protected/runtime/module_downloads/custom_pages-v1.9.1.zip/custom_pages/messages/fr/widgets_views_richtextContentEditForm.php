<?php
return array (
  'less' => 'moins...',
  'more' => 'plus...',
);
