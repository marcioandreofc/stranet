<?php
return array (
  'Here you can manage your template container elements.' => 'Vous pouvez gérer ici vos éléments de conteneur pour vos modèles.',
);
