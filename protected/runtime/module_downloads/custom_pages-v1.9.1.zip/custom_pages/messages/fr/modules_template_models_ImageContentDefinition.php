<?php
return array (
  'Height' => 'Hauteur',
  'Style' => 'Style',
  'Width' => 'Largeur',
);
