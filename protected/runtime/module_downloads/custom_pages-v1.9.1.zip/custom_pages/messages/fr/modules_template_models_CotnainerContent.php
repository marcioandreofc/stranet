<?php
return array (
  'Allow multiple items?' => 'Autoriser des éléments multiples ?',
  'Allowed Templates' => 'Modèles autorisés',
  'Render items as inline-blocks within the inline editor?' => 'Afficher les éléments comme des blocs en ligne au sein de l\'éditeur en ligne ?',
);
