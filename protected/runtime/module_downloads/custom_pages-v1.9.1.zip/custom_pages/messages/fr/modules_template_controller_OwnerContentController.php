<?php
return array (
  '<strong>Confirm</strong> container item deletion' => '<strong>Confirmer</strong> la suppression de l\'élément du conteneur',
  '<strong>Confirm</strong> content deletion' => '<strong>Confirmer</strong> la suppression du contenu',
  '<strong>Confirm</strong> element deletion' => '<strong>Confirmer</strong> la suppression de l\'élément',
);
