<?php
return array (
  'Choose a template' => 'Choisissez un modèle',
  'Template' => 'Modèle',
);
