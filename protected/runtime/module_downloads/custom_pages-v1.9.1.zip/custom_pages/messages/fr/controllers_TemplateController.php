<?php
return array (
  '<strong>Edit</strong> {type} element' => '<strong>Modifier</strong> l\'élément {type}',
  'Access denied!' => 'Accès refusé.',
  'Empty content elements cannot be delted!' => 'Les éléments avec des contenus vides ne peuvent pas être supprimés.',
  'Invalid request data!' => 'Données de la requête invalides.',
  'You are not allowed to delete default content!' => 'Vous n\'êtes pas autorisé à supprimer le contenu par défaut.',
);
