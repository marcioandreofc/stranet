<?php
return array (
  'Content' => 'Tarkib',
  'ID' => '',
  'Icon' => '',
  'Invalid template selection!' => '',
  'Invalid view file selection!' => '',
  'Sort Order' => '',
  'Style Class' => '',
  'Target Url' => '',
  'Template Layout' => '',
  'Title' => 'Sarlavha',
  'Type' => '',
);
