<?php

return [
    'Abstract' => '',
    'Navigation' => '',
    'Only visible for admins' => '',
    'Open in new window' => '',
    'Page' => '',
    'Url shortcut' => '',
    'View' => '',
    'page' => '',
];
