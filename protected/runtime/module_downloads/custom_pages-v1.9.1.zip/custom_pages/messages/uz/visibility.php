<?php

return [
    'Admin only' => '',
    'All Members' => '',
    'Members & Guests' => '',
    'Members only' => '',
    'Public' => '',
    'Space Members only' => '',
];
