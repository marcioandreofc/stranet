<?php
return array (
  'Content' => 'Tarkib',
  'Sidebar' => '',
  'snippet' => '',
);
