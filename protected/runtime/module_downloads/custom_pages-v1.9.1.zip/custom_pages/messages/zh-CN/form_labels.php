<?php
return array (
  'Url' => '网址',
  'View' => '',
);
