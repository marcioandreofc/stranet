<?php
return array (
  'Content' => '内容',
  'ID' => 'ID',
  'Icon' => '',
  'Invalid template selection!' => '',
  'Invalid view file selection!' => '',
  'Sort Order' => '',
  'Style Class' => '',
  'Target Url' => '',
  'Template Layout' => '',
  'Title' => '标题',
  'Type' => '类型',
);
