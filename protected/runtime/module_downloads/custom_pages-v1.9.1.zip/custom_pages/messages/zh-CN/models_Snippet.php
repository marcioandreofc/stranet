<?php
return array (
  'Content' => '内容',
  'Sidebar' => '',
  'snippet' => '',
);
