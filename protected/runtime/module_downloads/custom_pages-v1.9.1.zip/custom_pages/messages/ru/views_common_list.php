<?php

return [
    'This page lists all available custom content entries.' => '',
];
