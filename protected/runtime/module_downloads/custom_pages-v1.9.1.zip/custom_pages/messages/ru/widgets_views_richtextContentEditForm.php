<?php
return array (
  'less' => '',
  'more' => 'развернуть',
);
