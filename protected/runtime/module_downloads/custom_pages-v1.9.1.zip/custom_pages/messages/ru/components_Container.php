<?php
return array (
  'Content' => 'Контент',
  'ID' => 'ID',
  'Icon' => '',
  'Invalid template selection!' => '',
  'Invalid view file selection!' => '',
  'Sort Order' => 'Порядок сортировки',
  'Style Class' => '',
  'Target Url' => '',
  'Template Layout' => '',
  'Title' => 'Заголовок',
  'Type' => 'Тип',
);
