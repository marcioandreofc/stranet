<?php
return array (
  'Display Empty Content' => '',
  'Update' => 'Обновить',
);
