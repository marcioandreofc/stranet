<?php

return [
    'Only visible for space admins' => '',
    'Open in new window' => '',
];
