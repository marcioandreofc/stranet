<?php
return array (
  'Url' => 'Сайт',
  'View' => 'Просмотр',
);
