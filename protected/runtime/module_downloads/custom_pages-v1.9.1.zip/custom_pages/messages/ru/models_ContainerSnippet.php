<?php

return [
    'Snippet' => '',
    'snippet' => '',
];
