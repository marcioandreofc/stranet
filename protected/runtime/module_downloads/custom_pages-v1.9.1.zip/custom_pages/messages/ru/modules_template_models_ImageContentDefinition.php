<?php
return array (
  'Height' => 'Высота',
  'Style' => '',
  'Width' => 'Ширина',
);
