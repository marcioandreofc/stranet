<?php
return array (
  'Content' => 'Контент',
  'Sidebar' => '',
  'snippet' => '',
);
