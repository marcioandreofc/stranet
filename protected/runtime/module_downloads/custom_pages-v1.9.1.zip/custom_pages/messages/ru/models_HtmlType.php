<?php
return array (
  'Attach Files' => 'Загрузить фотографию или файл',
);
