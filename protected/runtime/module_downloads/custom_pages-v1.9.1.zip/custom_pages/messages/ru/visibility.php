<?php
return array (
  'Admin only' => '',
  'All Members' => '',
  'Members & Guests' => '',
  'Members only' => '',
  'Public' => 'Публичное',
  'Space Members only' => '',
);
