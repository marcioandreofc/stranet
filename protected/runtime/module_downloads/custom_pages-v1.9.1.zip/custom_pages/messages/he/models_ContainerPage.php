<?php
return array (
  'Only visible for space admins' => 'זמין רק לאדמין',
  'Open in new window' => 'פתח בחלון חדש',
);
