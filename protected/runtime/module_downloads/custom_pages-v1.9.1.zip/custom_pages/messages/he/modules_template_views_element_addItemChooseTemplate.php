<?php

return [
    'Choose a template' => '',
    'Template' => '',
];
