<?php

return [
    '<strong>Add</strong> {templateName} item' => '',
    '<strong>Edit</strong> item' => '',
];
