<?php

return [
    'Empty' => '',
    'Inline' => '',
    'Multiple' => '',
    'This template does not contain any elements yet.' => '',
];
