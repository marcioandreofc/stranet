<?php

return [
    '<strong>Confirm</strong> container item deletion' => '',
    '<strong>Confirm</strong> content deletion' => '',
    '<strong>Confirm</strong> element deletion' => '',
];
