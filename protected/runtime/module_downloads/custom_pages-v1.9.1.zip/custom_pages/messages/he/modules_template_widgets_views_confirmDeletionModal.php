<?php

return [
    'Are you sure you want to delete this container item?' => '',
    'Do you really want to delete this content?' => '',
    'Do you really want to delete this element? <br />The deletion will affect all pages using this template.' => '',
];
