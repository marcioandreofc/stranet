<?php

return [
    'Use empty content' => '',
];
