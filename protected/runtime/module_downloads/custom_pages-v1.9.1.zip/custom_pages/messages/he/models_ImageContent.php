<?php

return [
    'Empty Image' => '',
];
