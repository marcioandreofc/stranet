<?php
return array (
  'Show less' => 'הצג פחות',
  'Show more' => 'הצג יותר',
);
