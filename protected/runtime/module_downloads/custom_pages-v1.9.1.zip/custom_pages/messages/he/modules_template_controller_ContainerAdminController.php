<?php

return [
    'Here you can manage your template container elements.' => '',
];
