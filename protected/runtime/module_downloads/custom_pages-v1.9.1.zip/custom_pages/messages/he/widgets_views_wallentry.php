<?php

return [
    'Open page...' => '',
];
