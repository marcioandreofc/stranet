<?php

return [
    'Here you can manage your template layouts. Layouts are the root of your template pages and can not be combined with other templates.' => '',
];
