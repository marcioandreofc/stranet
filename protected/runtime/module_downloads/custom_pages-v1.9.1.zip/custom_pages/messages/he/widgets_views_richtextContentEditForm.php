<?php

return [
    'less' => '',
    'more' => '',
];
