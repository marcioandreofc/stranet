<?php

return [
    'Edit Template' => '',
    'Edit elements' => '',
    'Edit template' => '',
    'Page configuration' => '',
    'Turn edit off' => '',
];
