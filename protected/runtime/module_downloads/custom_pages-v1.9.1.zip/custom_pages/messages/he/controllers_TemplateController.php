<?php

return [
    '<strong>Edit</strong> {type} element' => '',
    'Access denied!' => '',
    'Empty content elements cannot be delted!' => '',
    'Invalid request data!' => '',
    'You are not allowed to delete default content!' => '',
];
