<?php

return [
    'Here you can manage your snipped layouts. Snippet layouts are templates, which can be included into sidebars.' => '',
];
