<?php
return array (
  'This page lists all available custom content entries.' => 'Na ovoj se stranici nalaze svi dostupni unosi prilagođenog sadržaja.',
);
