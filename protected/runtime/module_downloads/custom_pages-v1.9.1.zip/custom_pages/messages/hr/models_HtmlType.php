<?php
return array (
  'Attach Files' => 'Priložite datoteke',
);
