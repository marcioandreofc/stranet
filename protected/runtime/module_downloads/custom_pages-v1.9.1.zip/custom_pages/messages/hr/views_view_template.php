<?php
return array (
  'Edit Template' => 'Uredi predložak',
  'Edit elements' => 'Uredi elemente',
  'Edit template' => 'Uredi predložak',
  'Page configuration' => 'Konfiguracija stranice',
  'Turn edit off' => 'Isključite uređivanje',
);
