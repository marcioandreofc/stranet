<?php
return array (
  'Are you sure you want to delete this container item?' => 'Jeste li sigurni da želite izbrisati ovu stavku spremnika?',
  'Do you really want to delete this content?' => 'Želite li zaista izbrisati ovaj sadržaj?',
  'Do you really want to delete this element? <br />The deletion will affect all pages using this template.' => 'Želite li stvarno izbrisati ovaj element? <br>Brisanje će utjecati na sve stranice koje koriste ovaj predložak.',
);
