<?php
return array (
  'Content' => 'Sadržaj',
  'Sidebar' => 'Bočna traka',
  'snippet' => 'isječak',
);
