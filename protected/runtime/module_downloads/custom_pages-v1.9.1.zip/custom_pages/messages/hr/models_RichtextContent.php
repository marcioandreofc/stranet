<?php

return [
    'Empty HumHub Richtext' => '',
    'Empty Richtext' => '',
    'Empty Text' => '',
];
