<?php
return array (
  'Show less' => 'Prikaži manje',
  'Show more' => 'Prikaži više',
);
