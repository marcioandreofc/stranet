<?php
return array (
  'Here you can manage your template container elements.' => 'Ovdje možete upravljati elementima spremnika predloška.',
);
