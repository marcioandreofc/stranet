<?php
return array (
  'none' => 'nijedan/na',
);
