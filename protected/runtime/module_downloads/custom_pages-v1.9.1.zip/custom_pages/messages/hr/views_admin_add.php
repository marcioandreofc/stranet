<?php
return array (
  'Add new {pageType}' => 'Dodaj novu/i {pageType}',
  'Create new template' => 'Izradite novi predložak',
  'Edit template' => 'Uredi predložak',
  'Settings' => 'Postavke',
);
