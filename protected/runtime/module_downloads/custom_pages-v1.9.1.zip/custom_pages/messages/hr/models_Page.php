<?php
return array (
  'Abstract' => 'Sažetak',
  'Navigation' => 'Navigacija',
  'Only visible for admins' => 'Vidljivo samo za administratore',
  'Open in new window' => 'Otvori u novom prozoru',
  'Page' => 'Stranica',
  'Url shortcut' => 'Prečac za URL',
  'View' => 'Vidi',
  'page' => 'stranica',
);
