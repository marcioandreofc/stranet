<?php
return array (
  'less' => 'mindre',
  'more' => 'mer',
);
