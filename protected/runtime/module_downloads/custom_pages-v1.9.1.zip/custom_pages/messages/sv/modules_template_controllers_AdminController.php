<?php
return array (
  '<strong>Add</strong> new {type} element' => '<strong>Lägg till</strong> nytt {type} element',
  '<strong>Edit</strong> element {name}' => '<strong>Redigera</strong> element {name}',
  '<strong>Edit</strong> elements of {templateName}' => '<strong>Redigera</strong> elementen för {templateName}',
  '<strong>Edit</strong> {templateName}' => '<strong>Redigera</strong> {templateName}',
  'Template not found!' => 'Mallen kunde inte hittas!',
  'The template could not be deleted, please get sure that this template is not in use.' => 'Den här mallen kan inte tas bort. Kontrollera så att mallen inte används.',
);
