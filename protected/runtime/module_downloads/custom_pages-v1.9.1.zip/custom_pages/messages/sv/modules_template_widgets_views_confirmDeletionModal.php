<?php
return array (
  'Are you sure you want to delete this container item?' => 'Är du säker på att du vill ta bort det här containerobjektet?',
  'Do you really want to delete this content?' => 'Vill du verkligen ta bort det här innehållet?',
  'Do you really want to delete this element? <br />The deletion will affect all pages using this template.' => 'Vill du verkligen ta bort detta element? <br> Raderingen påverkar alla sidor som använder den här mallen.',
);
