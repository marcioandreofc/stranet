<?php
return array (
  'Show less' => 'Visa mindre',
  'Show more' => 'Visa mer',
);
