<?php
return array (
  'Snippet' => 'Snippet',
  'snippet' => 'snippet',
);
