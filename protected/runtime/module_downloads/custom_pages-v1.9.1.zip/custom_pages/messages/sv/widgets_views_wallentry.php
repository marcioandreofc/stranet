<?php
return array (
  'Open page...' => 'Öppna sida...',
);
