<?php
return array (
  'Here you can manage your template layouts. Layouts are the root of your template pages and can not be combined with other templates.' => 'Här kan du hantera dina malllayouter. Layouter är roten till dina mallsidor och kan inte kombineras med andra mallar.',
);
