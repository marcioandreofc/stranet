<?php
return array (
  'Use empty content' => 'Använd tomt innehåll',
);
