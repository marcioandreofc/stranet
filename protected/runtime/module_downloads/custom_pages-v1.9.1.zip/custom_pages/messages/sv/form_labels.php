<?php
return array (
  'Url' => 'Url',
  'View' => 'Visa',
);
