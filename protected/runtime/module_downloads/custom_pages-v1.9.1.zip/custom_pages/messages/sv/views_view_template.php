<?php
return array (
  'Edit Template' => 'Redigera Mall',
  'Edit elements' => 'Redigera element',
  'Edit template' => 'Redigera Mall',
  'Page configuration' => 'Konfigurera sida',
  'Turn edit off' => 'Slå av möjligheten att redigera',
);
