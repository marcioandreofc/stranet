<?php
return array (
  'Add Element' => 'Lägg till element',
  'Edit All' => 'Redigera alla',
  'Edit template \'{templateName}\'' => 'Redigera mallen \'{templateName}\'',
  'Here you can edit the source of your template by defining the template layout and adding content elements. Each element can be assigned with a default content and additional definitions.' => 'Här kan du redigera källan till din mall genom att definiera malllayouten och lägga till innehållselement. Varje element kan tilldelas ett standardinnehåll och ytterligare definitioner.',
  'You haven\'t saved your last changes yet. Do you want to leave without saving?' => 'Du har inte sparat dina senaste ändringar än. Vill du lämna sidan utan att spara?',
);
