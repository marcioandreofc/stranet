<?php
return array (
  'Here you can manage your template container elements.' => 'Här kan du hantera dina mallbehållares element.',
);
