<?php
return array (
  'Abstract' => 'Sammanfattning',
  'Navigation' => 'Navigation',
  'Only visible for admins' => 'Endast synligt för admin',
  'Open in new window' => 'Öppna i nytt fönster',
  'Page' => 'Sida',
  'Url shortcut' => 'URL genväg',
  'View' => 'Visa',
  'page' => 'sida',
);
