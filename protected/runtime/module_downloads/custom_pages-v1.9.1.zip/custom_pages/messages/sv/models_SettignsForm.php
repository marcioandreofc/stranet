<?php
return array (
  'Activate PHP based Pages and Snippets' => 'Aktivera PHP-baserade sidor och Snippets',
  'If disabled, existing php pages will still be online, but can\'t be created.' => 'Om inaktiverat kommer befintliga php-sidor fortfarande att vara online, men kan inte skapas.',
  'PHP view path for custom space pages' => 'PHP-visningsväg för anpassade nätverkssidor',
  'PHP view path for custom space snippets' => 'PHP sökväg för anpassade forum snippets',
  'PHP view path for global custom pages' => 'PHP sökväg för globala anpassade sidor',
  'PHP view path for global custom snippets' => 'PHP sökväg för globala anpassade snippets',
  'The given view file path does not exist.' => 'Den givna sökvägen för filen finns inte.',
);
