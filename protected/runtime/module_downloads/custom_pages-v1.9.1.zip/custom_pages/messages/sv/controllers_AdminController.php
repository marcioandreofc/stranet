<?php
return array (
  '<strong>Add</strong> {templateName} item' => '<strong>Lägg till</strong> {templateName} objekt',
  '<strong>Edit</strong> item' => '<strong>Redigera</strong> objekt',
);
