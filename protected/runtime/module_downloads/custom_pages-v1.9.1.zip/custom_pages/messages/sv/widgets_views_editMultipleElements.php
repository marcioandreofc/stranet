<?php
return array (
  'Empty' => 'Tom',
  'Inline' => 'Inbyggd',
  'Multiple' => 'Flera',
  'This template does not contain any elements yet.' => 'Den här mallen innehåller inga element än.',
);
