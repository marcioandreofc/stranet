<?php
return array (
  'Allow multiple items?' => 'Tillåta flera objekt?',
  'Allowed Templates' => 'Tillåtna mallar',
  'Render items as inline-blocks within the inline editor?' => 'Göra objekt som inline-block i inline-redigeraren?',
);
