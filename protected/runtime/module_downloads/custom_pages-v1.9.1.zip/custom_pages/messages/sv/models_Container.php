<?php
return array (
  'Empty <br />Container' => 'Tom <br>behållare',
);
