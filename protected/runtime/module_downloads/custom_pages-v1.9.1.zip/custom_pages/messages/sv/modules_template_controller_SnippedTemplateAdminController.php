<?php
return array (
  'Here you can manage your snipped layouts. Snippet layouts are templates, which can be included into sidebars.' => 'Här kan du hantera dina Snippets layouter. Snippetlayouter är mallar som kan inkluderas i sidofältet.',
);
