<?php
return array (
  '<strong>Confirm</strong> container item deletion' => '<strong>Bekräfta</strong> borttagning av behållarobjekt',
  '<strong>Confirm</strong> content deletion' => '<strong>Bekräfta</strong> borttagning av innehåll',
  '<strong>Confirm</strong> element deletion' => '<strong>Bekräfta</strong> borttagning av element',
);
