<?php
return array (
  'Choose a template' => 'Välj en mall',
  'Template' => 'Mall',
);
