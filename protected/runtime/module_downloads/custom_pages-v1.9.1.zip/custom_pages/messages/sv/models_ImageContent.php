<?php
return array (
  'Empty Image' => 'Tom bild',
);
