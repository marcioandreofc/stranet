<?php
return array (
  'Use default content' => 'Använd standardinnehåll',
);
