<?php
return array (
  'Label' => 'Etikett',
  'Placeholder name' => 'Namn för platshållare',
  'The element name must contain at least two characters without spaces or special signs except \'_\'' => 'Elementets namn måste innehålla minst två tecken utan mellanslag eller specialtecken utom \'_\'',
  'The given element name is already in use for this template.' => 'Det valda namnet för elementet används redan i den här mallen.',
);
