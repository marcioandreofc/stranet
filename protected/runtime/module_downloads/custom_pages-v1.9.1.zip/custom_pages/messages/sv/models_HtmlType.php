<?php
return array (
  'Attach Files' => 'Bifoga filer',
);
