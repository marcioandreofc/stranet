<?php
return array (
  'This page lists all available custom content entries.' => 'Denna sida visar alla tillgängliga anpassade innehållsposter.',
);
