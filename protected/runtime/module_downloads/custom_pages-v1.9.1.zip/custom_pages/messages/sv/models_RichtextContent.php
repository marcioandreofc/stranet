<?php
return array (
  'Empty HumHub Richtext' => 'Tom HumHub Richtext',
  'Empty Richtext' => 'Tom Richtext',
  'Empty Text' => 'Tom text',
);
