<?php
return array (
  'Display Empty Content' => 'Visa tomt innehåll',
  'Update' => 'Uppdatera',
);
