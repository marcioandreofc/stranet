<?php
return array (
  '<strong>Edit</strong> {type} element' => '<strong>Redigera</strong> {type} element',
  'Access denied!' => 'Tillträde nekas!',
  'Empty content elements cannot be delted!' => 'Tomma innehållselement kan inte raderas!',
  'Invalid request data!' => 'Ogiltig dataförfrågan!',
  'You are not allowed to delete default content!' => 'Du får inte ta bort standardinnehåll!',
);
