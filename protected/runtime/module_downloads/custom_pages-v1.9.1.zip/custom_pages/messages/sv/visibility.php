<?php
return array (
  'Admin only' => 'Endast administratör',
  'All Members' => 'Alla medlemmar',
  'Members & Guests' => 'Medlemmar &amp; gäster',
  'Members only' => 'Endast medlemmar',
  'Public' => 'Publik',
  'Space Members only' => 'Endast forummedlemmar',
);
