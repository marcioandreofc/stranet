<?php
return array (
  'none' => 'ingen',
);
