<?php
return array (
  'Content' => 'Innehåll',
  'Sidebar' => 'Sidovyn',
  'snippet' => 'snippet',
);
