<?php
return array (
  'Content' => 'Innehåll',
  'ID' => 'ID',
  'Icon' => 'Ikon',
  'Invalid template selection!' => 'Ogiltigt mallval!',
  'Invalid view file selection!' => 'Ogiltigt val för filgranskning!',
  'Sort Order' => 'Sorteringsordning',
  'Style Class' => 'Stilklass',
  'Target Url' => 'Mål URL',
  'Template Layout' => 'Mall layout',
  'Title' => 'Titel',
  'Type' => 'Typ',
);
