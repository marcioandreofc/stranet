<?php
return array (
  'View not found' => 'Vyn kunde inte hittas',
);
