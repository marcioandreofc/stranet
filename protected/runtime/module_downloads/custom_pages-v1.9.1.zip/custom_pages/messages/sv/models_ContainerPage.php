<?php
return array (
  'Only visible for space admins' => 'Endast synligt för forumadministratörer',
  'Open in new window' => 'Öppna i nytt fönster',
);
