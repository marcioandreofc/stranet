<?php
return array (
  'less' => '',
  'more' => 'بیشتر',
);
