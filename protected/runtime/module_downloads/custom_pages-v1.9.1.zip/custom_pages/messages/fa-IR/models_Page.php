<?php

return [
    'Navigation' => 'راهبری',
    'View' => 'نمایش',
    'Abstract' => '',
    'Only visible for admins' => '',
    'Open in new window' => '',
    'Page' => '',
    'Url shortcut' => '',
    'page' => '',
];
