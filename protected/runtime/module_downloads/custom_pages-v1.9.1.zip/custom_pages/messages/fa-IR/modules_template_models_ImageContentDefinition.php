<?php
return array (
  'Height' => 'بلندا',
  'Style' => '',
  'Width' => 'پهنا',
);
