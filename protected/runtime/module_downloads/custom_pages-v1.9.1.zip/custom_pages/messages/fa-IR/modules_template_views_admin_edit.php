<?php
return array (
  'Create new {type}' => '',
  'Edit template \'{templateName}\'' => '',
  'Save' => 'ذخیره',
);
