<?php
return array (
  'Add new {pageType}' => '',
  'Create new template' => '',
  'Edit template' => '',
  'Settings' => 'تنطیمات',
);
