<?php
return array (
  'Content' => 'محتوا',
  'ID' => 'شناسه',
  'Icon' => '',
  'Invalid template selection!' => '',
  'Invalid view file selection!' => '',
  'Sort Order' => 'ترتیب مرتب‌سازی',
  'Style Class' => '',
  'Target Url' => '',
  'Template Layout' => '',
  'Title' => 'عنوان',
  'Type' => 'تایپ',
);
