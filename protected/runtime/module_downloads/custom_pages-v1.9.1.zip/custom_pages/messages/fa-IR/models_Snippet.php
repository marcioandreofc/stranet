<?php
return array (
  'Content' => 'محتوا',
  'Sidebar' => '',
  'snippet' => '',
);
