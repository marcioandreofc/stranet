<?php
return array (
  'Show less' => 'نمایش کمتر',
  'Show more' => 'نمایش بیشتر',
);
