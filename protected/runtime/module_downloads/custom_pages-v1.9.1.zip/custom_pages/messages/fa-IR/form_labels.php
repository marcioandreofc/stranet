<?php
return array (
  'Url' => 'آدرس',
  'View' => 'نمایش',
);
