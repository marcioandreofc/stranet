<?php
return array (
  'Admin only' => '',
  'All Members' => '',
  'Members & Guests' => '',
  'Members only' => '',
  'Public' => 'همگانی',
  'Space Members only' => '',
);
