<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Šeit vēl nav nevienas aptaujas!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Šeit vēl nav nevienas aptaujas!</b><br>Esi pirmais un izveido kādu...',
  'Asked by me' => 'Manis jautāts',
  'No answered yet' => 'Vēl nav atbildes',
  'Only private polls' => 'Tikai privātas aptaujas',
  'Only public polls' => 'Tikai publiskas aptaujas',
);
