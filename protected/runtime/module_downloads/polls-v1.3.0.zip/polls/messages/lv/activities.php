<?php
return array (
  'Polls' => 'Aptaujas',
  'Whenever someone participates in a poll.' => '',
);
