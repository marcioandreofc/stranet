<?php
return array (
  'Access denied!' => 'دسترسي تاييد نشد',
  'Anonymous poll!' => 'راي دهي ناشناس',
  'Could not load poll!' => 'نظرسنجی بارگذاری نشد!',
  'Invalid answer!' => 'پاسخ نامعتبر!',
  'Users voted for: <strong>{answer}</strong>' => 'کاربران به <strong>{answer}</strong> رای دادند',
  'Voting for multiple answers is disabled!' => 'رای‌دادن به چند پاسخ غیرفعال است!',
  'You have insufficient permissions to perform that operation!' => 'شما  مجاز به انجام عملیات نیستید!',
);
