<?php
return array (
  'Polls' => 'نظرسنجی‌ها',
  'Whenever someone participates in a poll.' => '',
);
