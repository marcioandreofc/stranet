<?php
return array (
  'Access denied!' => 'Erişim engellendi!',
  'Anonymous poll!' => 'Misafir anket!',
  'Could not load poll!' => 'Anket yüklenemedi!',
  'Invalid answer!' => 'Geçersiz cevap!',
  'Users voted for: <strong>{answer}</strong>' => 'Kullanıcılar oyladı: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Birden fazla cevap için oylama devre dışı bırakıldı!',
  'You have insufficient permissions to perform that operation!' => 'Bu işlemi gerçekleştirmek için yeterli izinlere sahip değilsiniz!',
);
