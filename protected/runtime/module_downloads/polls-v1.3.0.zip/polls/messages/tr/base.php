<?php

return [
    'Allows to start polls.' => 'Anket başlatmaya izin verir.',
    'Answers' => 'Cevaplar',
    'At least one answer is required' => 'En az bir cevap gerekli',
    'Cancel' => 'İptal',
    'Polls' => 'Anketler',
    'Save' => 'Kaydet',
    'Allows the user to create polls' => '',
    'Create poll' => '',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
