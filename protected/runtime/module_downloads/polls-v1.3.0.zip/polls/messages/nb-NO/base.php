<?php

return [
    'Allows to start polls.' => 'Tillater å starte en meningsmåling.',
    'Answers' => 'Svar',
    'At least one answer is required' => 'Minst et svar er påkrevd',
    'Cancel' => 'Avbryt',
    'Polls' => 'Meningsmålinger',
    'Save' => 'Lagre',
    'Allows the user to create polls' => '',
    'Create poll' => '',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
