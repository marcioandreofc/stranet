<?php
return array (
  'Polls' => 'Опросы',
  'Whenever someone participates in a poll.' => '',
);
