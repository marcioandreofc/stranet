<?php

return [
    'Answers' => '',
    'Description' => '',
    'Multiple answers per user' => '',
    'Please specify at least {min} answers!' => '',
    'Poll' => '',
    'Question' => '',
];
