<?php

return [
    'Allows the user to create polls' => '',
    'Allows to start polls.' => '',
    'Answers' => '',
    'At least one answer is required' => '',
    'Cancel' => '',
    'Create poll' => '',
    'Polls' => '',
    'Save' => '',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
