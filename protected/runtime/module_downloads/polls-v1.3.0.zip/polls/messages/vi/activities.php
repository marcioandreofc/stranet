<?php
return array (
  'Polls' => 'Biểu quyết',
  'Whenever someone participates in a poll.' => '',
);
