<?php
return array (
  'Ask' => 'Umfrage erstellen',
);
