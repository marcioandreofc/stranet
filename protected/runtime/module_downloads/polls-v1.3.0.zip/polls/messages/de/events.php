<?php
return array (
  'Again? ;Weary;' => 'Noch einmal? ;Weary;',
  'Club A Steakhouse' => 'Club A Steakhaus',
  'Location of the next meeting' => 'Ort der nächsten Besprechung',
  'Pisillo Italian Panini' => 'Pisillo Italian Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Wir sind gerade in den Planungen für unser nächstes Treffen. Wo möchtet ihr gerne hingehen?',
  'To Daniel' => 'Zu Daniel',
  'Why don\'t we go to Bemelmans Bar?' => 'Warum gehen wir nicht zu Bemelmans Bar?',
);
