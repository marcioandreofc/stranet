<?php

return [
    'Answers' => 'Svar',
    'Description' => 'Beskrivning',
    'Multiple answers per user' => 'Flera svar per användare',
    'Please specify at least {min} answers!' => 'Ange minst {min} svar!',
    'Question' => 'Fråga',
    'Poll' => '',
];
