<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>OBS:</strong> Resultatet är dolt tills undersökningen är stängd av moderatorn.',
  'Anonymous' => 'Anonym',
  'Closed' => 'Stängd',
  'Complete Poll' => 'Avsluta undersökning',
  'Reopen Poll' => 'Återöppna undersökning',
  'Reset my vote' => 'Återställ min röstning',
  'Vote' => 'Rösta',
  'and {count} more vote for this.' => 'och {count} fler röster för detta.',
  'votes' => 'röster',
);
