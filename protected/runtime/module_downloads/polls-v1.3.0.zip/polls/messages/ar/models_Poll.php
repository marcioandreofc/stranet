<?php

return [
    'Description' => 'توضيج',
    'Answers' => '',
    'Multiple answers per user' => '',
    'Please specify at least {min} answers!' => '',
    'Poll' => '',
    'Question' => '',
];
