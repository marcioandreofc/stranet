<?php
return array (
  'Access denied!' => 'Pääsy kieletty!',
  'Anonymous poll!' => 'Anonyymi kysely!',
  'Could not load poll!' => 'Kyselyä ei voitu ladata!',
  'Invalid answer!' => 'Väärä vastaus!',
  'Users voted for: <strong>{answer}</strong>' => 'Käyttäjät äänestivät: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Voit äänestää vain kerran!',
  'You have insufficient permissions to perform that operation!' => 'Sinulla ei ole oikeuksia tähän!',
);
