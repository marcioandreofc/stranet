<?php
return array (
  'Again? ;Weary;' => 'Ξανά; Κουρασμένος;',
  'Club A Steakhouse' => 'Club A Steakhouse',
  'Location of the next meeting' => 'Τοποθεσία επόμενης συνάντησης',
  'Pisillo Italian Panini' => 'Pisillo Italian Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Αυτή την στιγμή είμαστε στον σχεδιασμό της επόμενης συνάντησής μας και θα θέλαμε από εσάς να μας πείτε, που θα προτιμούσατε να πάτε;',
  'To Daniel' => 'Προς τον Daniel',
  'Why don\'t we go to Bemelmans Bar?' => 'Γιατί δεν πήγαίνουμε στο Bemelmans;',
);
