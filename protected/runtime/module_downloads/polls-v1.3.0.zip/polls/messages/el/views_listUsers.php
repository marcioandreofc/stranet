<?php
return array (
  'User who vote this' => 'Χρήστες που το ψήφισαν',
);
