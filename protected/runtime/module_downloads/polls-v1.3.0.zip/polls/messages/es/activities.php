<?php
return array (
  'Polls' => 'Encuestas',
  'Whenever someone participates in a poll.' => 'Siempre que alguien participe en una encuesta.',
);
