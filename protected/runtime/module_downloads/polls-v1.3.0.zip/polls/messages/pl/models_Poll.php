<?php
return array (
  'Answers' => 'Odpowiedzi',
  'Description' => 'Opis',
  'Multiple answers per user' => 'Wielokrotne odpowiedzi na użytkownika',
  'Please specify at least {min} answers!' => 'Proszę określ przynajmniej {min} odpowiedzi!',
  'Poll' => 'Pytanie',
  'Question' => 'Pytanie',
);
