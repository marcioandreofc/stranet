<?php
return array (
  'Access denied!' => 'Brak dostępu!',
  'Anonymous poll!' => 'Głosowanie anonimowe!',
  'Could not load poll!' => 'Nie można wczytać głosowania! ',
  'Invalid answer!' => 'Nieprawidłowa odpowiedź! ',
  'Users voted for: <strong>{answer}</strong>' => 'Użytkownicy głosowali na: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Głosowanie na wielokrotne odpowiedzi jest zabronione! ',
  'You have insufficient permissions to perform that operation!' => 'Masz niewystarczające uprawnienia aby przeprowadzić tę operację! ',
);
