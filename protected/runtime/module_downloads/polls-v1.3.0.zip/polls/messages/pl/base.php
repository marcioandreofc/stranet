<?php

return [
    'Allows the user to create polls' => 'Pozwalaj użytkownikom na tworzenie ankiet',
    'Allows to start polls.' => 'Pozwala dodawać głosowania.',
    'Answers' => 'Odpowiedzi',
    'At least one answer is required' => 'Przynajmniej jedna odpowiedź jest wymagana',
    'Cancel' => 'Anuluj',
    'Create poll' => 'Utwórz ankietę',
    'Polls' => 'Głosowania',
    'Save' => 'Zapisz',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
