<?php
return array (
  'Allows the user to create polls' => 'Autoriser les utilisateurs à créer un sondage',
  'Allows to start polls.' => 'Ce module permet de créer des sondages.',
  'Answers' => 'Réponses',
  'At least one answer is required' => 'Au moins une réponse est obligatoire',
  'Cancel' => 'Annuler',
  'Create poll' => 'Créer un sondage',
  'Polls' => 'Sondages',
  'Save' => 'Enregistrer',
  '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}',
);
