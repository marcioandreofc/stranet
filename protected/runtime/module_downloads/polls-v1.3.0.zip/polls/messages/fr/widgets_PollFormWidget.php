<?php
return array (
  'Ask' => 'Demander',
);
