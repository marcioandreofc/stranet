<?php
return array (
  'User who vote this' => 'Utilisateurs qui vont voter',
);
