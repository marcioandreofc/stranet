<?php
return array (
  '{userName} answered the {question}.' => '{userName} votou sobre {question}.',
);
