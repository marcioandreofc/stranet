<?php

return [
    'Allows the user to create polls' => 'Permite à pessoa criar votações',
    'Allows to start polls.' => 'Permite iniciar votações.',
    'Answers' => 'Opções',
    'At least one answer is required' => 'Pelo menos uma opção é necessária',
    'Cancel' => 'Cancelar',
    'Create poll' => 'Criar votação',
    'Polls' => 'Votações',
    'Save' => 'Guardar',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
