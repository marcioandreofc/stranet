<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Ainda não há votações!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Ainda não há votações!</b><br>Cria agora a primeira...',
  'Asked by me' => 'Perguntado por mim',
  'No answered yet' => 'Ainda sem resultados',
  'Only private polls' => 'Só votações privadas',
  'Only public polls' => 'Só votações públicas',
);
