<?php
return array (
  'User who vote this' => 'Pessoa que votou nisto',
);
