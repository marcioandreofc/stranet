<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>หมายเหตุ:</strong> ผลลัพธ์จะถูกซ่อนไว้จนกว่าโพลล์จะปิดโดยผู้ดูแล',
  'Anonymous' => 'ไม่ระบุชื่อ',
  'Closed' => 'ปิด',
  'Complete Poll' => 'กรอกแบบสำรวจ',
  'Reopen Poll' => 'เปิดโพลอีกครั้ง',
  'Reset my vote' => 'รีเซ็ตการโหวตของฉัน',
  'Vote' => 'โหวต',
  'and {count} more vote for this.' => 'และอีก {count} โหวตสำหรับสิ่งนี้',
  'votes' => 'โหวต',
);
