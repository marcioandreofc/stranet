<?php
return array (
  'Access denied!' => 'ปฏิเสธการเข้าใช้!',
  'Anonymous poll!' => 'โพลนิรนาม!',
  'Could not load poll!' => 'ไม่สามารถโหลดแบบสำรวจความคิดเห็น!',
  'Invalid answer!' => 'คำตอบที่ไม่ถูกต้อง!',
  'Users voted for: <strong>{answer}</strong>' => 'ผู้ใช้โหวตให้: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'การลงคะแนนหลายคำตอบถูกปิดการใช้งาน!',
  'You have insufficient permissions to perform that operation!' => 'คุณมีสิทธิ์ไม่เพียงพอที่จะดำเนินการดังกล่าว!',
);
