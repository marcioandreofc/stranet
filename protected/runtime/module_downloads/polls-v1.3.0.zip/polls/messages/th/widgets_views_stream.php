<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>ยังไม่มีการสำรวจความคิดเห็น!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>ยังไม่มีการสำรวจความคิดเห็น!</b><br>เป็นคนแรกและสร้างมันขึ้นมา...',
  'Asked by me' => 'ถามโดยฉัน',
  'No answered yet' => 'ยังไม่มีคำตอบ',
  'Only private polls' => 'เฉพาะโพลส่วนตัว',
  'Only public polls' => 'เฉพาะโพลสาธารณะ',
);
