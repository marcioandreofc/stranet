<?php
return array (
  'Ask' => 'ถาม',
);
