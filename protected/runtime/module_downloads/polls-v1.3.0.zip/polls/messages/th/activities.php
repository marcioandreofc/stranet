<?php
return array (
  'Polls' => 'โพล',
  'Whenever someone participates in a poll.' => 'เมื่อใดก็ตามที่มีคนมีส่วนร่วมในการสำรวจความคิดเห็น',
);
