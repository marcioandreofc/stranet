<?php

return [
    'Answers' => 'คำตอบ',
    'Description' => 'คำอธิบาย',
    'Multiple answers per user' => 'หลายคำตอบต่อผู้ใช้',
    'Please specify at least {min} answers!' => 'โปรดระบุอย่างน้อย {min} คำตอบ!',
    'Question' => 'คำถาม',
    'Poll' => '',
];
