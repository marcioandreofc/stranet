<?php

return [
    'Allows to start polls.' => '允许开始投票',
    'Answers' => '答案',
    'Cancel' => '取消',
    'Polls' => '投票',
    'Save' => '保存',
    'Allows the user to create polls' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
