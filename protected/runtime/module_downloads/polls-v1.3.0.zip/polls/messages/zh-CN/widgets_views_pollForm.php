<?php
return array (
  'Add answer...' => '添加答案...',
  'Anonymous Votes?' => '匿名投票？',
  'Description' => '描述',
  'Display answers in random order?' => '随机位置显示答案？',
  'Edit answer (empty answers will be removed)...' => '编辑答案(空答案会被删除)...',
  'Edit your poll question...' => '编辑投票问题...',
  'Hide results until poll is closed?' => '',
  'Question' => '问题',
);
