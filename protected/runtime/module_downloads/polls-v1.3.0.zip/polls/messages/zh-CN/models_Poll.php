<?php

return [
    'Answers' => '答案',
    'Description' => '描述',
    'Multiple answers per user' => '每个用户多个答案',
    'Please specify at least {min} answers!' => '请指定最少{min}个答案！',
    'Question' => '问题',
    'Poll' => '',
];
