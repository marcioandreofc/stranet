<?php
return array (
  'Answers' => 'Odgovori',
  'Description' => 'Opis',
  'Multiple answers per user' => 'Višestruki odgovori po korisniku',
  'Please specify at least {min} answers!' => 'Molimo odaberite barem {min} odgovora!',
  'Poll' => 'Pitanje',
  'Question' => 'Pitanje',
);
