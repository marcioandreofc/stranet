<?php
return array (
  'Add answer...' => 'Dodaj odgovor...',
  'Anonymous Votes?' => 'Anonimni glasovi?',
  'Description' => 'Opis',
  'Display answers in random order?' => 'Prikaži odgovore u nasumičnom redoslijedu?',
  'Edit answer (empty answers will be removed)...' => 'Uredi odgovor (prazni odgovori viti će uklonjeni)...',
  'Edit your poll question...' => 'Uredi anketno pitanje...',
  'Hide results until poll is closed?' => 'Sakrij rezultate dok se anketa ne zatvori?',
  'Question' => 'Pitanje',
);
