<?php

return [
    'Allows to start polls.' => 'Dopusti pokretanje ankete',
    'Answers' => 'Odgovori',
    'At least one answer is required' => 'Potreban je barem jedan odgovor',
    'Cancel' => 'Poništi',
    'Polls' => 'Ankete',
    'Save' => 'Spremi',
    'Allows the user to create polls' => '',
    'Create poll' => '',
    '{n,plural,=1{# {htmlTagBegin}vote{htmlTagEnd}}other{# {htmlTagBegin}votes{htmlTagEnd}}}' => '',
];
