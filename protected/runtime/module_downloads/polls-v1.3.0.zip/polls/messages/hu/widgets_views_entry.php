<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Megjegyzés</strong> Az eredmények a szavazás végéig nem láthatóak.',
  'Anonymous' => 'Névtelen / Ismeretlen',
  'Closed' => 'Befejeződött',
  'Complete Poll' => 'Szavazás lezárása',
  'Reopen Poll' => 'Szavazás újbóli megnyitása',
  'Reset my vote' => 'Szavazatom visszavonása',
  'Vote' => 'Szavazok',
  'and {count} more vote for this.' => 'és még {count} ember szavazott erre.',
  'votes' => 'szavazat',
);
