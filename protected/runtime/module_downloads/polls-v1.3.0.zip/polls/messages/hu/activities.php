<?php
return array (
  'Polls' => 'Szavazások',
  'Whenever someone participates in a poll.' => 'Amikor valaki részt vesz egy szavazásban.',
);
