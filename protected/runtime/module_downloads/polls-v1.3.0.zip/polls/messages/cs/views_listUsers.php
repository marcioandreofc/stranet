<?php
return array (
  'User who vote this' => 'Uživatelé, kteří pro to hlasovali',
);
