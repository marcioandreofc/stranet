<?php
return array (
  'Access denied!' => 'Přístup odepřen!',
  'Anonymous poll!' => 'Anonymní anketa!',
  'Could not load poll!' => 'Nebylo možné načíst anketu!',
  'Invalid answer!' => 'Neplatná odpověď!',
  'Users voted for: <strong>{answer}</strong>' => 'Uživatelé, kteří hlasovali pro odpověď: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Není možné hlasovat pro více odpovědí!',
  'You have insufficient permissions to perform that operation!' => 'Pro tuto operaci nemáte dostatečná oprávnění!',
);
