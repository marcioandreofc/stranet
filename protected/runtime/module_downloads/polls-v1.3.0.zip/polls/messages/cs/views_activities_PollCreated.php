<?php
return array (
  '{userName} created a new {question}.' => '{userName} položil(a) otázku {question}.',
);
