<?php
return array (
  'Polls' => 'Ankety',
  'Whenever someone participates in a poll.' => '',
);
