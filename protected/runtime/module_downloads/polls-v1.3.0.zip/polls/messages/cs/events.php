<?php

return [
    'Again? ;Weary;' => 'Znovu? ;Unavený;',
    'Club A Steakhouse' => 'Steakhouse',
    'Pisillo Italian Panini' => 'Pisillo italské Panini',
    'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Právě teď jsme ve fázi plánování pro další setkání a my bychom rádi věděli, kam byste chtěli jít?',
    'To Daniel' => 'Danielovi',
    'Why don\'t we go to Bemelmans Bar?' => 'Proč nejdeme do Bemelmans Bar?',
    'Location of the next meeting' => '',
];
