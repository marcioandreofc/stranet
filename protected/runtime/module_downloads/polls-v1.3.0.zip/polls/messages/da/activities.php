<?php
return array (
  'Polls' => 'Afstemninger',
  'Whenever someone participates in a poll.' => '',
);
