<?php
return array (
  'Add answer...' => 'Antwoord toevoegen...',
  'Anonymous Votes?' => 'Anoniem stemmen?',
  'Description' => 'Beschrijving',
  'Display answers in random order?' => 'Antwoorden in willekeurige volgorde weergeven?',
  'Edit answer (empty answers will be removed)...' => 'Antwoorden veranderen (Lege antwoorden worden verwijderd)',
  'Edit your poll question...' => 'Verander de vraag...',
  'Hide results until poll is closed?' => 'Verberg de resultaten tot de sluiting van de stembus?',
  'Question' => 'Vraag',
);
